(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_investor-relations_page_e5321739.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_investor-relations_page_e5321739.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_7a7f4780._.js",
    "static/chunks/node_modules_53dd7620._.js",
    "static/chunks/src_app_ada279cc._.js"
  ],
  "source": "dynamic"
});
