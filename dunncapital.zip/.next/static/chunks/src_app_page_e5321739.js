(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_e5321739.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_e5321739.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_8eb2e012._.js",
    "static/chunks/src_app_271339ea._.js",
    "static/chunks/node_modules_next_88edab54._.js",
    "static/chunks/node_modules_swiper_ddde4a28._.js",
    "static/chunks/node_modules_framer-motion_dist_es_2e6f230b._.js",
    "static/chunks/node_modules_371c7563._.js",
    "static/chunks/node_modules_swiper_acd668f0._.css"
  ],
  "source": "dynamic"
});
