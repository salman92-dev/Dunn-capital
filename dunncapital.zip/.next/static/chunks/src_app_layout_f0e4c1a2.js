(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_f0e4c1a2.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_f0e4c1a2.js",
  "chunks": [
    "static/chunks/src_app_globals_b805903d.css"
  ],
  "source": "dynamic"
});
